$LOAD_PATH << File.expand_path(File.dirname(__FILE__))

require 'beaker-puppet'
