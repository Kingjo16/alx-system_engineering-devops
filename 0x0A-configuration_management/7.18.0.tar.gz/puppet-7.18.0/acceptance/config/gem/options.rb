{
  # Use `git` so that we have a sane ruby environment
  :type => 'git',
}
