require_relative '../../puppet/application/face_base'
require_relative '../../puppet/face'

class Puppet::Application::Parser < Puppet::Application::FaceBase
end
