require_relative '../../puppet/application/face_base'

class Puppet::Application::Config < Puppet::Application::FaceBase
  environment_mode :not_required
end
