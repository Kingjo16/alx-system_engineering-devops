require_relative '../../puppet/application/face_base'

# The Generate application. 
class Puppet::Application::Generate < Puppet::Application::FaceBase
end
