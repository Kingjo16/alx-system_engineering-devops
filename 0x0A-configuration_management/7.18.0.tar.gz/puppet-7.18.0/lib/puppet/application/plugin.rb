require_relative '../../puppet/application/face_base'
class Puppet::Application::Plugin < Puppet::Application::FaceBase
  environment_mode :not_required
end
