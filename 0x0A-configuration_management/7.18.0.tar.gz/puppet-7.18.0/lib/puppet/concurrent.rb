module Puppet::Concurrent
end
